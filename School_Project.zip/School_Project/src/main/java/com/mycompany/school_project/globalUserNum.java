/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.school_project;

/**
 *
 * @author Ala'a
 */
public class globalUserNum {
    private static globalUserNum instance;
    private int userNum;

    private globalUserNum() {
        // Private constructor to prevent instantiation
    }

    public static synchronized globalUserNum getInstance() {
        if (instance == null) {
            instance = new globalUserNum();
        }
        return instance;
    }

    public int getSharedValue() {
        return userNum;
    }

    public void setSharedValue(int value) {
        this.userNum = value;
    }
}
