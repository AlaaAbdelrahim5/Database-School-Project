/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.school_project;

/**
 *
 * @author Ala'a
 */
public class School_Project {

    public static void main(String[] args) {
        Login_Page Hi = new Login_Page();
        Hi.setVisible(true);
    }
}
